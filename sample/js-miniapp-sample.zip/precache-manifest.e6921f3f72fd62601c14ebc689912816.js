self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e2f4fb8af6b5cecb4cb4b62c4d8532cd",
    "url": "./index.html"
  },
  {
    "revision": "332f79be38603d04a90e",
    "url": "./static/css/main.c080e719.chunk.css"
  },
  {
    "revision": "f84d463e77d8f3280c3b",
    "url": "./static/js/2.fcb92ad9.chunk.js"
  },
  {
    "revision": "621e67c148318da922fd8fcb225944ab",
    "url": "./static/js/2.fcb92ad9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "332f79be38603d04a90e",
    "url": "./static/js/main.955082e7.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "364527c2e605f90324c7680dbd72c188",
    "url": "./static/media/panda.364527c2.png"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road_webp.825bfa3b.gif"
  },
  {
    "revision": "4f774d08f0c3e66594704d6be4a2d052",
    "url": "./static/media/sample.4f774d08.mp3"
  },
  {
    "revision": "b43c2c4343f355d31a8f3512238f6f79",
    "url": "./static/media/sample.b43c2c43.zip"
  }
]);