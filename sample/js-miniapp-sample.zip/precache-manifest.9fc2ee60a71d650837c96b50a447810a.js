self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6ed16ae76b55918706047b36cae701c2",
    "url": "./index.html"
  },
  {
    "revision": "ff34823f4e6c220d07cd",
    "url": "./static/css/main.00a5e04a.chunk.css"
  },
  {
    "revision": "8302a3c31d86ad97c73a",
    "url": "./static/js/2.08cccf0d.chunk.js"
  },
  {
    "revision": "d5fdc2cde9ddad10560909af38ec8a94",
    "url": "./static/js/2.08cccf0d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ff34823f4e6c220d07cd",
    "url": "./static/js/main.6f5fc728.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road_webp.825bfa3b.gif"
  }
]);