self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6e01b79e895f26f2e6bc9d8193ad319b",
    "url": "./index.html"
  },
  {
    "revision": "e3b44b5a9582b7b84fe2",
    "url": "./static/css/main.c080e719.chunk.css"
  },
  {
    "revision": "4eeff4f2dd549e910100",
    "url": "./static/js/2.81daf883.chunk.js"
  },
  {
    "revision": "621e67c148318da922fd8fcb225944ab",
    "url": "./static/js/2.81daf883.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e3b44b5a9582b7b84fe2",
    "url": "./static/js/main.4c18e7ea.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road_webp.825bfa3b.gif"
  }
]);