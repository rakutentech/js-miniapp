self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "03af5eecf5e4d2db19b6c5ad6c6c5cf3",
    "url": "./index.html"
  },
  {
    "revision": "7365a99c7547bb28d09c",
    "url": "./static/css/main.c080e719.chunk.css"
  },
  {
    "revision": "8a8bc29665af5dd2be17",
    "url": "./static/js/2.bd48be0d.chunk.js"
  },
  {
    "revision": "4937214ce7d0ed9a1cce597098cb7423",
    "url": "./static/js/2.bd48be0d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7365a99c7547bb28d09c",
    "url": "./static/js/main.82a2b097.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road_webp.825bfa3b.gif"
  }
]);