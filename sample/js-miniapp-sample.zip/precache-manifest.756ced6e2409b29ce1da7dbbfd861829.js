self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9ad6a301380c3d867e2ea81514583e95",
    "url": "./index.html"
  },
  {
    "revision": "c9e1c172d6ab49f9c9d8",
    "url": "./static/css/main.c080e719.chunk.css"
  },
  {
    "revision": "1a251b3a1bb251b95a16",
    "url": "./static/js/2.1d2f56fd.chunk.js"
  },
  {
    "revision": "621e67c148318da922fd8fcb225944ab",
    "url": "./static/js/2.1d2f56fd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c9e1c172d6ab49f9c9d8",
    "url": "./static/js/main.f303720f.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road.825bfa3b.webp"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  }
]);