self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9fd5532166b8473d8a58562797a50290",
    "url": "./index.html"
  },
  {
    "revision": "7a362c4e5c0ef60d61d8",
    "url": "./static/css/main.c080e719.chunk.css"
  },
  {
    "revision": "ab52ecffeb716682b201",
    "url": "./static/js/2.3cf44f13.chunk.js"
  },
  {
    "revision": "621e67c148318da922fd8fcb225944ab",
    "url": "./static/js/2.3cf44f13.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7a362c4e5c0ef60d61d8",
    "url": "./static/js/main.201848c9.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road_webp.825bfa3b.gif"
  }
]);