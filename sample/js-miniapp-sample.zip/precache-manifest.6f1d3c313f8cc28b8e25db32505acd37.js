self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fc9098d9ba294903767fe7851a53ff31",
    "url": "./index.html"
  },
  {
    "revision": "b337e9c902eaad5002a5",
    "url": "./static/css/main.c080e719.chunk.css"
  },
  {
    "revision": "0c59bdb309a3591d9b4f",
    "url": "./static/js/2.fa4bc66d.chunk.js"
  },
  {
    "revision": "621e67c148318da922fd8fcb225944ab",
    "url": "./static/js/2.fa4bc66d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b337e9c902eaad5002a5",
    "url": "./static/js/main.e48dcd58.chunk.js"
  },
  {
    "revision": "ad5018763faec8908a97",
    "url": "./static/js/runtime-main.1c088e3e.js"
  },
  {
    "revision": "364527c2e605f90324c7680dbd72c188",
    "url": "./static/media/panda.364527c2.png"
  },
  {
    "revision": "7a89d3ee362ead4d31aa6c1900aaee85",
    "url": "./static/media/road.7a89d3ee.gif"
  },
  {
    "revision": "c6606fc4f02eae41405b0aa8105a7f56",
    "url": "./static/media/road_infinite.c6606fc4.gif"
  },
  {
    "revision": "825bfa3bb135130d890828d1416c60a9",
    "url": "./static/media/road_webp.825bfa3b.gif"
  },
  {
    "revision": "4f774d08f0c3e66594704d6be4a2d052",
    "url": "./static/media/sample.4f774d08.mp3"
  },
  {
    "revision": "b43c2c4343f355d31a8f3512238f6f79",
    "url": "./static/media/sample.b43c2c43.zip"
  }
]);